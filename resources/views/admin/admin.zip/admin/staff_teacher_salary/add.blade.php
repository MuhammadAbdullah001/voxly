@extends('layouts.admin.master')

@section('content')
    <!-- Main content -->
    <div class="content-wrapper">

        <!-- Page header -->
        <div class="page-header page-header-light">
            <div class="page-header-content header-elements-md-inline">
                <div class="page-title d-flex">
                    <h4><span class="font-weight-semibold">Teacher Salary </span> - Add</h4>
                    <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
                </div>

                {{--                <div class="header-elements d-none">--}}
{{--                    <div class="d-flex justify-content-center">--}}
{{--                        <a href="{{asset('/admin/booking')}}" class="btn btn-link btn-float font-size-sm font-weight-semibold text-default">--}}
{{--                            <i class="icon-store text-pink-300"></i>--}}
{{--                            <span>Inventory</span>--}}
{{--                        </a>--}}
{{--                        <a href="{{asset('/admin/booking')}}" class="btn btn-link btn-float font-size-sm font-weight-semibold text-default">--}}
{{--                            <i class="icon-paypal2 text-pink-300"></i>--}}
{{--                            <span>Payment</span>--}}
{{--                        </a>--}}
{{--                        <a href="{{asset('/admin/booking')}}" class="btn btn-link btn-float font-size-sm font-weight-semibold text-default">--}}
{{--                            <i class="icon-alarm text-pink-300"></i>--}}
{{--                            <span>Timesheet</span>--}}
{{--                        </a>--}}
{{--                    </div>--}}
{{--                </div>--}}
            </div>

{{--            <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">--}}
{{--                <div class="d-flex">--}}
{{--                    <div class="breadcrumb">--}}
{{--                        <a href="{{asset('/admin/booking')}}" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Dashboard</a>--}}
{{--                        <span class="breadcrumb-item active">Record Attendance</span>--}}
{{--                    </div>--}}

{{--                    <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>--}}
{{--                </div>--}}
{{--            </div>--}}
        </div>
        <!-- /page header -->


        <!-- Content area -->
        <div class="content">


            <?php if(isset($data['danger_msg']) && $data['danger_msg']){ ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-danger alert-styled-left alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                        <span class="font-weight-semibold">Oh snap!</span> <?php echo $data['danger_msg']; ?>
                    </div>
                </div>
            </div>
            <?php } ?>


                <?php if(!empty($errors->all()) && $errors->all()){ ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger alert-styled-left alert-dismissible">


                            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                            @foreach ($errors->all() as $error)

                                <span class="font-weight-semibold">Oh snap!</span> {{ $error }}
                                <br>
                            @endforeach


                        </div>
                    </div>

                </div>
                <?php } ?>
                @if(session()->has('success'))

                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-success alert-styled-left alert-arrow-left alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                                <span class="font-weight-semibold">Well done!</span> {{ session()->get('success') }}
                            </div>
                        </div>
                    </div>


                @endif
                @if(session()->has('error'))

                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-danger alert-styled-left alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
                                <span class="font-weight-semibold">Oh snap!</span>{{ session()->get('error') }}
                            </div>
                        </div>
                    </div>
                @endif

            <div class="card">
                <div class="card-header">
                    <div class="header-elements-inline">
                        <h4 class="card-title">Add Salary  </h4>
                    </div>
                </div>
                <hr>

                <div class="card-body">

                    <form action="{{url('admin/teacher-salary/add')}}" method="post">
                        @csrf

                        <div class="form-group required row">
                            <label class="col-form-label col-lg-2 control-label">Salary From Date</label>
                            <div class="col-lg-4">
                                <div class="input-group">
                                    <input type="text" id="salary_from_date" value="{{ old('salary_from_date') }}"  name="salary_from_date" class="form-control daterange-single" required>
                                </div>
                            </div>
                            <label class="col-form-label col-lg-2 text-center control-label">Salary To Date</label>
                            <div class="col-lg-4">
                                <div class="input-group">

                                    <input type="text" id="salary_to_date" value="{{ old('salary_to_date') }}"  name="salary_to_date" class="form-control daterange-single" required>

                                </div>
                            </div>
                        </div>

                        <!-- <div class="form-group required row">
                            <label class="col-form-label col-lg-2 control-label">Select Group</label>
                            <div class="col-lg-10">
                                <div class="input-group">
                                    <select   required  class="form-control  js-example-tags "   id="teacher-group-renamed">
                                        <option value="">--- Select ---</option>

                                        <?php
                                        if( isset($data['groups']) && !empty($data['groups'])){
                                        foreach ($data['groups'] as $group){ ?>
                                        <option value="<?php  echo $group->id; ?>"><?php   echo $group->name; ?> </option>

                                        <?php }
                                        }

                                        ?>


                                    </select>
                                </div>
                            </div>
                        </div> -->


                        <div class="form-group required row">
                            <label class="col-form-label col-lg-2 control-label">Staff Name</label>
                            <div class="col-lg-10">
                                <div class="input-group">
                                    <select required class="js-example-basic-single form-control js-example-theme-single select" id="teacher_list" name="teacher_id">
                                        <option value = "0">--Please Select--</option>
                                        <?php
                                        if( isset($data['teachers']) && !empty($data['teachers'])){
                                        foreach ($data['teachers'] as $teacher){ ?>
                                        <option value="<?php  echo $teacher->id; ?>"><?php   echo $teacher->name; ?> </option>

                                        <?php }
                                        }

                                        ?>

                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group required row">
                            <label class="col-md-2 col-form-label control-label">Salary Duration(Days)</label>
                            <div class="col-md-10">
                                <input type="number"   id="salary_duration"  value="{{ old('salary_duration') }}"   name="salary_duration" class="form-control" placeholder="Enter Salary Duration(Days)" required>
                            </div>
                        </div>

                        <div class="form-group required row" id="expected_salary_container">
                            <label class="col-md-2 col-form-label" id="expected_fee_label">Expected Fee By Attendance(Days)</label>
                            <div class="col-md-10">
                                <input type="number" readonly  value="{{ old('expected_salary_value') }}"   id="expected_salary_value" value="" name="expected_salary_value"   class="form-control" >
                            </div>
                        </div>

                        <div class="form-group required row">
                            <label class="col-md-2 col-form-label control-label">Amount</label>
                            <div class="col-md-10">
                                <input type="number"   id="salary_amount"   value="{{ old('salary_amount') }}"  name="amount" class="form-control" placeholder="Enter Salary Amount" required>
                            </div>
                        </div>

                        <div class="form-group required row">
                            <label class="col-form-label col-lg-2 control-label">Payment Type</label>
                            <div class="col-lg-10">
                                <div class="input-group">
                                    <select name="payment_type" class=" form-control-select2 form-control" required id="expense_category">
                                        <option value="">--- SELECT ---</option>
                                        <option value="cash">Cash</option>
                                        <option value="bank_transfer">Bank Transfer</option>
                                        <option value="card">Card</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="form-group required row">

                            <label class="col-md-2 col-form-label control-label">Entry Date</label>
                            <div class="col-md-10">
                                <input type="text" id="date" name="date" value="{{ old('date') }}"  class="form-control daterange-single" required>
                            </div>

                        </div>

                        <div class="form-group row">
                            <label class="col-form-label col-lg-2">Description</label>
                            <div class="col-lg-10">
                                <div class="input-group">
                                    <textarea name="description"  value="{{ old('description') }}"  class="form-control" ></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="mt-5 mb-2 d-md-flex  justify-content-md-between flex-md-wrap">
                             <button type="submit" id="salary_submit_btn" class="btn bg-primary d-flex align-items-center">
                                Submit <i class="icon-paperplane ml-2"></i> </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
        <!-- /content area -->
        @include('layouts.footer')

    </div>

    <!-- /main content -->

@endsection
