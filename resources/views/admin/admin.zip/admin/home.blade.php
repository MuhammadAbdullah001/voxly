@extends('layouts.admin.master')

@section('content')

    <!-- Main content -->
    <div class="content-wrapper">

        <!-- Page header -->
        <div class="page-header page-header-light">
            <div class="page-header-content header-elements-md-inline">
                <div class="page-title d-flex">
                    <h4><i class="icon-arrow-left52 mr-2"></i> <span class="font-weight-semibold"></span>  Dashboard</h4>
                    <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
                </div>

{{--                <div class="header-elements d-none">--}}
{{--                    <div class="d-flex justify-content-center">--}}
{{--                        <a href="{{asset('/admin/booking')}}" class="btn btn-link btn-float font-size-sm font-weight-semibold text-default">--}}
{{--                            <i class="icon-calendar52 text-pink-300"></i>--}}
{{--                            <span>Booking</span>--}}
{{--                        </a>--}}
{{--                        <a href="{{asset('/admin/finance')}}" class="btn btn-link btn-float font-size-sm font-weight-semibold text-default">--}}
{{--                            <i class="icon-cash3  text-pink-300"></i>--}}
{{--                            <span>Invoices</span>--}}
{{--                        </a>--}}
{{--                        <a href="{{asset('/admin/support')}}" class="btn btn-link btn-float font-size-sm font-weight-semibold text-default">--}}
{{--                            <i class="icon-lifebuoy text-pink-300"></i>--}}
{{--                            <span>Support</span>--}}
{{--                        </a>--}}
{{--                    </div>--}}
{{--                </div>--}}
            </div>

            <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
{{--                <div class="d-flex">--}}
{{--                    <div class="breadcrumb">--}}
{{--                        <a href="{{asset('/admin/home')}}" class="breadcrumb-item"><i class="icon-home2 mr-2"></i>Dashboard</a>--}}
{{--                        <span class="breadcrumb-item active">Home</span>--}}
{{--                    </div>--}}

{{--                    <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>--}}
{{--                </div>--}}

                <div class="header-elements d-none">
                    <div class="breadcrumb justify-content-center">

{{--                        <div class="breadcrumb-elements-item dropdown p-0">--}}
{{--                            <a href="#" class="breadcrumb-elements-item" >--}}
{{--                                <!-- <a href="#" class="breadcrumb-elements-item dropdown-toggle" data-toggle="dropdown"> -->--}}
{{--                                <i class="icon-gear mr-2"></i>--}}
{{--                                Settings--}}
{{--                            </a>--}}

                            <!-- <div class="dropdown-menu dropdown-menu-right">
                                <a href="#" class="dropdown-item"><i class="icon-user-lock"></i> Account security</a>
                                <a href="#" class="dropdown-item"><i class="icon-statistics"></i> Analytics</a>
                                <a href="#" class="dropdown-item"><i class="icon-accessibility"></i> Accessibility</a>
                                <div class="dropdown-divider"></div>
                                <a href="#" class="dropdown-item"><i class="icon-gear"></i> All settings</a>
                            </div> -->
{{--                        </div>--}}
                    </div>
                </div>
            </div>
        </div>
        <!-- /page header -->

        <!-- Content area -->
        <div class="content">

            <div class="row justify-content-center">
                <div class="col-md-12"><br>
                    <div class="mb-3">

                        <div class="float-right">

                            <a class="btn bg-success btn-ladda btn-ladda-progress ladda-button legitRipple float-right" href="<?php echo url('admin/student-fee/add'); ?>" ><i class="icon-cash4 badge-warning"></i> Click To Make Fee Transaction</a>



                        </div>

                        <h6 class="mb-0 font-weight-semibold">
                            {{--@if(Auth::user()->type==1)--}}
                            {{--Super Admin--}}
                            {{--@elseif(Auth::user()->type==2)--}}
                            {{--Admin--}}
                            {{--@elseif(Auth::user()->type==3)--}}
                            {{--Branch Manager--}}
                            {{--@elseif(Auth::user()->type==4)--}}
                            {{--Receptionist--}}
                            {{--@endif--}}
                        </h6>
                        <span class="text-muted d-block">Dashboard</span>
                    </div>

                    <div class="card">
                        <div class="card-header"></div>

                        <div class="card-body">
                            <!-- Simple statistics -->

                            <div class="row">

                                <div class="col-sm-6 col-xl-3">
                                    <a href="{{url('admin/admission')}}" class="nav-link">

                                        <div class="card card-body bg-danger-400 has-bg-image">
                                            <div class="media">
                                                <div class="media-body">
                                                    <h3 class="mb-0">{{ ($data['admissions_active'])}}</h3>
                                                    <span class="text-uppercase font-size-xs">Active <br> Admissions</span>
                                                    <h3 class="mb-0">{{($data['admissions_inactive'])}}</h3>
                                                    <span class="text-uppercase font-size-xs">Inactive <br> Admissions</span>
                                                </div>

                                                <div class="ml-3 align-self-center">
                                                    <i class="icon-user-lock icon-3x opacity-75"></i>
                                                </div>
                                            </div>
                                        </div></a>
                                </div>

                                <div class="col-sm-6 col-xl-3">
                                    <a href="{{url('admin/student')}}" class="nav-link">

                                        <div class="card card-body bg-blue-400 has-bg-image">
                                            <div class="media">
                                                <div class="media-body">
                                                    <h3 class="mb-0">{{($data['student_active'])}}</h3>
                                                    <span class="text-uppercase font-size-xs">Active<br>  Students</span>
                                                    <h3 class="mb-0">{{($data['student_inactive'])}}</h3>
                                                    <span class="text-uppercase font-size-xs">Inactive <br> Students</span>
                                                </div>

                                                <div class="ml-3 align-self-center">
                                                    <i class="icon-user-check icon-3x opacity-75"></i>
                                                </div>
                                            </div>
                                        </div></a>
                                </div>


                                <div class="col-sm-6 col-xl-3">
                                    <a href="{{url('admin/staff')}}" class="nav-link">

                                        <div class="card card-body bg-success-400 has-bg-image">
                                            <div class="media">
                                                <div class="media-body">
                                                    <h3 class="mb-0">{{($data['teacher_active'])}}</h3>
                                                    <span class="text-uppercase font-size-xs">Active<br>  Teachers</span>
                                                    <h3 class="mb-0">{{($data['teacher_inactive'])}}</h3>
                                                    <span class="text-uppercase font-size-xs">Inactive <br> Teachers</span>
                                                </div>

                                                <div class="ml-3 align-self-center">
                                                    <i class="icon-people icon-3x opacity-75"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </a> </div>
                                <div class="col-sm-6 col-xl-3">
                                    <a href="{{url('admin/expenses')}}" class="nav-link">

                                        <div class="card card-body bg-warning-400 has-bg-image">
                                            <div class="media">
                                                <div class="media-body">
                                                    <h3 class="mb-0">&pound;{{number_format($data['fees_paid_sum'],0)}}</h3>
                                                    <span class="text-uppercase font-size-xs"> Monthly<br> Fees</span>
                                                    <h3 class="mb-0">&pound;{{number_format($data['expenses_sum_monthly'],0)}}</h3>
                                                    <span class="text-uppercase font-size-xs"> Monthly<br>  Expenses</span>
                                                </div>

                                                <div class="ml-3 align-self-center">
                                                    <i class="icon-user-check icon-3x opacity-75"></i>
                                                </div>
                                            </div>
                                        </div></a>
                                </div>

                            </div>
                            <!-- /simple statistics -->
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="mb-3">
                        <h6 class="mb-0 font-weight-semibold">
                            Monthly Fees Paid
                        </h6>
                        <span class="text-muted d-block">Recent Fees</span>
                    </div>

                    <div class="card">
                        <div class="card-header header-elements-sm-inline">
                            <h6 class="card-title">Fees</h6>
                        </div>
                        <div class="row">


                            <div class="col-md-12">


                                <table class="table datatable-basic-desc table table-responsive table-bordered">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Admission No</th>
                                        <th>Student Name</th>
                                        <th>Fee From Date</th>
                                        <th>Fee To Date</th>
                                        <th>Fee Entry Date</th>
                                        <th>Paid Duration</th>
                                        <th>Agreed Fee/hr</th>
                                        <th>Agreed hrs</th>
                                        <th>Payment Type</th>
                                        <th>Expected Fee</th>
                                        <th>Fee Taken</th>
                                        <th>Status</th>
                                        <th>description</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(isset($data['student_fees']) && count($data['student_fees'])>0){ foreach($data['student_fees']  as $d){ ?>
                                    <tr <?php if (isset($d->is_update) && $d->is_update == 1){ ?> class="bg bg-warning" <?php } ?>>
                                        <td>{{$d->id }}</td>
                                        <td>{{$d->admission_no }}</td>
                                        <td>{{$d->student->student_name }}</td>
                                        <td>{{$d->from_date }}</td>
                                        <td>{{$d->to_date }}</td>
                                        <td>{{$d->entry_date }}</td>
                                        <td>{{$d->paid_duration }}</td>
                                        <td>{{$d->agreed_fee_per_hr }}</td>
                                        <td>{{$d->agreed_hrs }}</td>
                                        <td> {{ strtoupper(str_replace('_',' ',$d->payment_type)) }}</td>
                                        <td>{{ number_format($d->expected_amount,0) }}</td>
                                        <td>{{ number_format($d->amount_taken,0) }}</td>
                                        <td class="bg bg-success text-center">{{  $d->status }}</td>

                                        <td >{{  $d->description }}</td>


                                    </tr>
                                    <?php }} ?>
                                    </tbody>
                                </table>
                                <div class="card-footer ">
                                    <div class="header-elements row">

                                        <h5 class="col-md-10"></h5>
                                        <h5 class="col-md-1">Total </h5>

                                        <p  class="col-md-1  btn btn-primary legitRipple">&pound;{{ number_format($data['total'],0) }}</p>
                                    </div>
                                </div>
                            </div>

                            <!-- Basic pie -->

                            <!-- /basic pie -->

                        </div>
                    </div>

                </div>

            </div>




        </div>
        {{--content end--}}
        @include('layouts.footer')

    </div>
    {{--content wrapper--}}
@endsection
